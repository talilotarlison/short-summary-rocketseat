import './styles/style.css';
import './styles/base.css';
import './styles/response.css';


const form = document.getElementById("form");

const input = document.querySelector("#url");

const conteudo = document.querySelector("#conteudo");


form.addEventListener("submit", (e) => {
  e.preventDefault();
  // faça a validação ou processamento adicional aqui
  const videoUrl = input.value;

  if (!videoUrl.includes("shorts")) {
    return conteudo.textContent = "O video não é um Shots!"
  }

  const [_, params] = videoUrl.split("/shorts/");

  const [id] = params.split("?si")

  console.log(id)

})