# Vite ⚡

> Next Generation Frontend Tooling

All you need to do is hit run and start making changes which will be updated live.

You can add install and use npm packages, you can use the Packager tool to search and manage your packages.

[Read the Docs to Learn More](https://vitejs.dev) and configure your frontend application.


> Uso da biblioteca de icones
[phosphoricons](https://phosphoricons.com/)

> cancelar evento form
>https://horadecodar.com.br/como-parar-envio-de-formulario-com-javascript/